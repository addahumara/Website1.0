from django.apps import AppConfig


class CollegesConfig(AppConfig):
    name = 'Colleges'
